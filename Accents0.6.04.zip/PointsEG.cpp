#define BUILDOPT_VERBOSE
#define BUILDOPT_DEBUG_LEVEL 10

#include <od/constants.h>
#include </home/joe/Accents/Accents/PointsEG.h>
#include <od/config.h>
#include <hal/ops.h>
#include <hal/log.h>

DXEG::DXEG()
{
    addInput(mGate);
    addInput(mL1);
    addInput(mL2);
    addInput(mL3);
    addInput(mL4);
    addInput(mR1);
    addInput(mR2);
    addInput(mR3);
    addInput(mR4);
    addParameter(mC1);
    addParameter(mC2);
    addParameter(mC3);
    addParameter(mC4);
    addOutput(mOutput);
    addOption(mGateHighFlavor);
}

DXEG::~DXEG()
{
}

inline float DXEG::getSlope(float targetLevel, float currentLevel, float targetRate)
{

    return (targetLevel - currentLevel) / targetRate;
}

inline float DXEG::getNextOutput(int currentStage, Bezier::Bezier<2> b, float rate)
{
    float xVal;
    float t = mElapsedTime / rate;
    xVal = b.valueAt(t, 1);
    //logDebug(1,"t: %f --- Elapsed time: %f --- xVal: %f",t,mElapsedTime,xVal);
    return xVal;
}

inline bool DXEG::isStageComplete(float slope, float target, float current) 
{
    if (slope <=0 && current <= target)
    {
        return true;
    }
    else if (slope > 0 && current >= target) {
        return true;
    }
    else return false;
}


inline float DXEG::next(float l1, float l2, float l3, float l4, float r1, float r2, float r3, float r4, Bezier::Bezier<2> b1, Bezier::Bezier<2> b2, Bezier::Bezier<2> b3, Bezier::Bezier<2> b4)
{
    switch (mStage)
    {
    case 0: // waiting for trigger
        break;
    case 1: // stage 1 - travel to L1 at R1

        ///mSlope = getSlope(l1, mCapture, r1);
        

        // if (isStageComplete(mSlope,l1,mCurrentValue))
        if (mElapsedTime > r1)
        {
            mCapture = mCurrentValue;
            mStage = 2;
        }
        else
        {
            //mCurrentValue += (mSlope * globalConfig.samplePeriod);
            mCurrentValue = getNextOutput(mStage, b1, r1);
        }
        break;
    case 2: // stage 2 - travel to L2 at R2
        //mSlope = getSlope(l2, mCapture, r2);
        //if (isStageComplete(mSlope,l2,mCurrentValue))
        if (mElapsedTime > r2)
        {
            mCapture = mCurrentValue;
            mStage = 3;
        }
        else
        {
            // mCurrentValue += (mSlope * globalConfig.samplePeriod);
            mCurrentValue = getNextOutput(mStage, b2, r2);
        }
        break;
    case 3: // stage 3 - travel to L3 at R3
        // mSlope = getSlope(l3, mCapture, r3);

        // if (isStageComplete(mSlope,l3,mCurrentValue))
        if (mElapsedTime > r3)
        {
            mCapture = mCurrentValue;
            mStage = 4;
        }
        else
        {
            // mCurrentValue += (mSlope * globalConfig.samplePeriod);
            mCurrentValue = getNextOutput(mStage, b3, r3);
        }
        break;        
    case 4: // stage 4 - sustain at L3
        if (mGateHighFlavor.value() == DXEG_HIGATE_LOOP)
        {
            mCapture = mCurrentValue;
            mStage = 1;
        }
        else
        {
            mCurrentValue = l3;
        }
        break;
    case 5: // stage 5 - travel to L4 at R4
        // mSlope = getSlope(l4, mCapture, r4);
        // if (isStageComplete(mSlope,l4,mCurrentValue))
        if (mElapsedTime > r4)
        {
            mCapture = mCurrentValue;
            mStage = 0;
        }
        else
        {
            // mCurrentValue += (mSlope * globalConfig.samplePeriod);
            mCurrentValue = getNextOutput(mStage, b4, r4);
        }
        break;
    }
    mElapsedTime += globalConfig.samplePeriod;
    return mCurrentValue;
}


void DXEG::process()
{
    float *gate = mGate.buffer();
    float *out = mOutput.buffer();
    float *l1 = mL1.buffer();
    float *l2 = mL2.buffer();
    float *l3 = mL3.buffer();
    float *l4 = mL4.buffer();
    float *r1 = mR1.buffer();
    float *r2 = mR2.buffer();
    float *r3 = mR3.buffer();
    float *r4 = mR4.buffer();
    float c1 = mC1.value();
    float c2 = mC2.value();
    float c3 = mC3.value();
    float c4 = mC4.value();

    // Only recalculate bezier curves at the frame rate
    // first point is 0, previous level
    // second point is half rate, previous level + target level / 2 +/- (previous level + target level / 2) *curve
    // third point is rate, target level
    Bezier::Bezier<2> points1({ {0, l4[0]}, {r1[0] / 2, (l4[0] + l1[0] / 2) + c1 * (l4[0] + l1[0] / 2)}, {r1[0], l1[0]} });
    Bezier::Bezier<2> points2({ {0, l1[0]}, {r2[0] / 2, (l1[0] + l2[0] / 2) + c2 * (l1[0] + l2[0] / 2)}, {r2[0], l2[0]} });
    Bezier::Bezier<2> points3({ {0, l2[0]}, {r3[0] / 2, (l2[0] + l3[0] / 2) + c3 * (l2[0] + l3[0] / 2)}, {r3[0], l3[0]} });
    Bezier::Bezier<2> points4({ {0, l3[0]}, {r4[0] / 2, (l3[0] + l4[0] / 2) + c4 * (l3[0] + l4[0] / 2)}, {r4[0], l4[0]} });



    for (int i = 0; i < FRAMELENGTH; i++)
    {
        if ((mStage == 0 || mStage == 5))
        {
            // envelope is inactive
            if (gate[i] > 0.5f)
            {
                // turn on
                mStage = 1;
                mCapture = mCurrentValue;
                mElapsedTime = 0.0f;
            }
        }
        else
        {
            // envelope is active
            if (gate[i] < 0.5f)
            {
                // turn off
                mStage = 5;
                mCapture = mCurrentValue;
                mElapsedTime = 0.0f;
            }
        }

        
        out[i] = next(l1[i], l2[i], l3[i], l4[i], MAX(0.0001f,r1[i]), MAX(0.0001f,r2[i]), MAX(0.0001f,r3[i]), MAX(0.0001f,r4[i]),points1, points2, points3, points4);
    }
}
