
#include <od/objects/Object.h>
#include </home/joe/Accents/Accents/bezier/include/bezier.h>

#define DXEG_HIGATE_SUSTAIN 1
#define DXEG_HIGATE_LOOP 2

class DXEG : public od::Object
{
public:
    DXEG();
    virtual ~DXEG();

#ifndef SWIGLUA
    virtual void process();
    od::Inlet mL1{"L1"};
    od::Inlet mL2{"L2"};
    od::Inlet mL3{"L3"};
    od::Inlet mL4{"L4"};
    od::Inlet mR1{"R1"};
    od::Inlet mR2{"R2"};
    od::Inlet mR3{"R3"};
    od::Inlet mR4{"R4"};
    od::Parameter mC1{"C1",0.0f};
    od::Parameter mC2{"C2",0.0f};
    od::Parameter mC3{"C3",0.0f};
    od::Parameter mC4{"C4",0.0f};
    od::Inlet mGate{"Gate"};
    od::Outlet mOutput{"Out"};
    od::Option mGateHighFlavor{"GateHighFlavor"};
#endif

private:
    float next(float l1, float l2, float l3, float l4, float r1, float r2, float r3, float r4, Bezier::Bezier<2> b1, Bezier::Bezier<2> b2, Bezier::Bezier<2> b3, Bezier::Bezier<2> b4);
    float getSlope(float targetLevel, float currentLevel, float targetRate);
    bool isStageComplete(float slope, float target, float current);
    inline float getNextOutput(int currentStage, Bezier::Bezier<2> b, float rate);

    int mStage = 0;
    float mCapture = 0.0f;
    float mSlope = 0.0f;
    float mCurrentValue = 0.0f;
    float mElapsedTime = 0.0f;

    Bezier::Bezier<2> points1;
    Bezier::Bezier<2> points2;
    Bezier::Bezier<2> points3;
    Bezier::Bezier<2> points4;
    Bezier::Point p;


};
